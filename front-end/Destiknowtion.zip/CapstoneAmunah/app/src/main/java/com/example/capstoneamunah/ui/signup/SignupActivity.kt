package com.example.capstoneamunah.ui.signup

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import com.example.capstoneamunah.R
import com.example.capstoneamunah.databinding.ActivitySignupBinding
import com.example.capstoneamunah.ui.ViewModelFactory
import com.example.capstoneamunah.utils.LoadingDialog

class SignupActivity : AppCompatActivity() {

    private var _binding: ActivitySignupBinding? = null
    private val binding get() = _binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.title = resources.getString(R.string.register)
        val loadingDialog: LoadingDialog = LoadingDialog(this@SignupActivity)
        val factory: ViewModelFactory = ViewModelFactory.getInstance(this@SignupActivity)
        val viewModel: SignupViewModel by viewModels {
            factory
        }

        binding?.apply {
            signupButton.setOnClickListener {
                if (nameEditText.text!!.isNotEmpty() && emailEditText.text!!.isNotEmpty() && passwordEditText.text!!.isNotEmpty()) {
                    loadingDialog.showLoadingDialog()
                    viewModel.initiateRegistration(
                        nameEditText.text.toString(),
                        emailEditText.text.toString(),
                        passwordEditText.text.toString(),
                        this@SignupActivity,
                        loadingDialog
                    )
                } else {
                    Toast.makeText(
                        this@SignupActivity,
                        resources.getString(R.string.empty_input),
                        Toast.LENGTH_SHORT
                    ).show()
                }

            }
        }
    }

    companion object {
        const val NAME_ACTIVITY = "SignupActivity"
    }
}
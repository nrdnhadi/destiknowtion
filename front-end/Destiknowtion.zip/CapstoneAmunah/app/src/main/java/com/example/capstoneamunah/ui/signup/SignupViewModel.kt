package com.example.capstoneamunah.ui.signup

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.ViewModel
import com.example.capstoneamunah.data.UserRepository
import com.example.capstoneamunah.data.response.SignupResponse
import com.example.capstoneamunah.data.retrofit.ApiConfig
import com.example.capstoneamunah.utils.LoadingDialog
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignupViewModel(private val userRepository: UserRepository) : ViewModel() {
    fun initiateRegistration(
        name: String,
        email: String,
        password: String,
        context: SignupActivity,
        loadingIndicator: LoadingDialog
    ) {
        val client = ApiConfig.getApiServices().signupUser(name, email, password)
        client.enqueue(object : Callback<SignupResponse> {
            override fun onResponse(
                call: Call<SignupResponse>,
                response: Response<SignupResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        loadingIndicator.hideLoadingDialog()
                        Log.d(SignupActivity.NAME_ACTIVITY, responseBody.toString())
                        Toast.makeText(context, responseBody.message, Toast.LENGTH_SHORT)
                            .show()
                        context.finish()
                    }
                } else {
                    val errorBody = response.errorBody()?.string()
                    val errorMessage = JSONObject(errorBody).getString("message")
                    Toast.makeText(context, errorMessage, Toast.LENGTH_SHORT).show()
                    loadingIndicator.hideLoadingDialog()
                }
            }

            override fun onFailure(call: Call<SignupResponse>, t: Throwable) {
                loadingIndicator.hideLoadingDialog()
                Toast.makeText(context, t.message.toString(), Toast.LENGTH_SHORT).show()
                Log.d(SignupActivity.NAME_ACTIVITY, t.message.toString())
            }
        })
    }
}

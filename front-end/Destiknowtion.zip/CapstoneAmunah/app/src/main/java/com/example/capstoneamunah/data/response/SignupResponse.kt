package com.example.capstoneamunah.data.response

import com.google.gson.annotations.SerializedName

data class SignupResponse(

	@field:SerializedName("user_id")
	val userId: Int,

	@field:SerializedName("message")
	val message: String,

	@field:SerializedName("status")
	val status: Int
)

package com.example.capstoneamunah.data.retrofit

import com.example.capstoneamunah.data.response.LoginResponse
import com.example.capstoneamunah.data.response.SignupResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Headers
import retrofit2.http.POST

interface ApiService {
    // endpoint Signup
    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("api/signup")
    fun signupUser(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ) : Call<SignupResponse>


    // endpoint login
    @FormUrlEncoded
    @POST("api/login")
    fun loginUser(
        @Field("email") email: String,
        @Field("password") password: String
    ) : Call<LoginResponse>
}